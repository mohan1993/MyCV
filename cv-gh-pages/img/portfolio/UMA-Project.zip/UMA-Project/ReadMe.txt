The File Contains 
1) UMA- PRoject ( Complete project)
2) Master Thesis Report
3) Master Thesis PPT Slides

The UMA project contains .apk file

Steps to Install .apk file on your android device

1) Copy the .apk file and paste it to your android device 
2) Open file manager in your android device.
3) Install UMA app.
4) Enjoy the Application.

Setting up UMA project in your device.

1) Setup Eclipse
2) Setup Android Development Tools
3) Import the android project to your eclipse workspace.
3) Compile tess-two
4) Update all required Android Libraries.
5) Now you are ready to start your emulator.

If any queries
email: mohan.prasad725@gmail.com

Author: 
Mohan Prasad 