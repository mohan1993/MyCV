package Core.Dialogs;



import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import com.proj.uba.R;


@TargetApi(Build.VERSION_CODES.HONEYCOMB)
public class ImageDialog extends DialogFragment implements OnClickListener {

    private Bitmap bmp;

    private String title;

    public ImageDialog(){}

    public static ImageDialog New(){
        return new ImageDialog();
    }

    public ImageDialog addBitmap(Bitmap bmp) {
        if (bmp != null)
            this.bmp = bmp;
        return this;
    }

    public ImageDialog addTitle(String title) {
        if (title != null)
            this.title = title;
        return this;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.image_dialog, null);

        ImageView imageView = (ImageView) view.findViewById(R.id.image_dialog_imageView);
        TextView textView = (TextView) view.findViewById(R.id.image_dialog_textView);
        Button btnClose = (Button) view.findViewById(R.id.btnClose);
        
        btnClose.setOnClickListener(this);
        
        if (bmp != null)
            imageView.setImageBitmap(bmp);

        if(title!=null)
            textView.setText(this.title);
        return view;
    }

    @SuppressLint("NewApi")
	@Override
    public void onDismiss(DialogInterface dialog) {
        bmp.recycle();
        bmp = null;
        System.gc();
        super.onDismiss(dialog);
    }

	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		super.dismiss();
	}
}