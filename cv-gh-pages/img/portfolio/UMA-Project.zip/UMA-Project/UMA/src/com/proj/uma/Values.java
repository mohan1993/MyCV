package com.proj.uma;

import android.app.Application;

public class Values extends Application {

	public String internalValue;
	public String externalValue;

	public String getInternalValue() {
		return internalValue;
	}

	public void setInternalValue(String internalValue) {
		this.internalValue = internalValue;
	}

	public String getExternalValue() {
		return externalValue;
	}

	public void setExternalValue(String externalValue) {
		this.externalValue = externalValue;
	}

}
