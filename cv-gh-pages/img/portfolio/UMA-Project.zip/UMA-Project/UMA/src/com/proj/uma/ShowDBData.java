package com.proj.uma;

import com.proj.uba.R;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TableRow.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;

public class ShowDBData extends Activity implements OnClickListener {

	TableLayout tb;
	Button btnGetData;
	DatePicker dpFrom;
	DatePicker dpTo;

	DatabaseCommunicator loginDataBaseAdapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.dbdata);
		tb = (TableLayout) findViewById(R.id.tbDbData);
		btnGetData = (Button) findViewById(R.id.btnGetData);
		dpFrom = (DatePicker) findViewById(R.id.dpFrom);
		dpTo = (DatePicker) findViewById(R.id.dpto);

		btnGetData.setOnClickListener(this);
		tb.setStretchAllColumns(true);
		tb.bringToFront();

		loginDataBaseAdapter = new DatabaseCommunicator(this);
		loginDataBaseAdapter = loginDataBaseAdapter.open();
		String columns[] = { "DT", "INTERNAL", "EXTERNAL" };
		// Cursor resultSet =
		// loginDataBaseAdapter.db.execSQL("select *  from datapaid");
		// Cursor resultSet = loginDataBaseAdapter.db.query("DATAPAID", columns,
		// null, null, null, null, null);
		// String sql = "select * from DATAPAID";
	}

	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		switch (arg0.getId()) {

		case R.id.btnGetData:
			
			String fromMonth, toMonth, fromDay, toDay;
			
			fromMonth = ""+(dpFrom.getMonth() + 1);
			toMonth = ""+(dpTo.getMonth() + 1);
			
			fromDay = ""+dpFrom.getDayOfMonth();
			toDay = ""+dpTo.getDayOfMonth();
			
			
			if(Integer.parseInt(fromDay)>9){
				fromDay = ""+dpFrom.getDayOfMonth();
			}else{
				fromDay = "0"+dpFrom.getDayOfMonth();
			}
			
			
			if(Integer.parseInt(toDay)>9){
				toDay = ""+dpTo.getDayOfMonth();
			}else{
				toDay = "0"+dpTo.getDayOfMonth();
			}
			
			if(Integer.parseInt(fromMonth)>9){
				fromMonth = ""+(dpFrom.getMonth() + 1);
			}else{
				fromMonth = "0"+(dpFrom.getMonth() + 1);
			}
			
			if(Integer.parseInt(toMonth)>9){
				toMonth = ""+(dpTo.getMonth() + 1);
			}else{
				toMonth = "0"+(dpTo.getMonth() + 1);
			}
			
			
			Toast.makeText(getApplicationContext(), "From:"+dpFrom.getYear() + "-" + fromMonth
					+ "-" + dpFrom.getDayOfMonth(), Toast.LENGTH_LONG).show();
			Toast.makeText(getApplicationContext(), "To:"+dpTo.getYear() + "-" + toMonth + "-"
					+ dpTo.getDayOfMonth(), Toast.LENGTH_LONG).show();
			
			String from = dpFrom.getYear() + "-" + fromMonth + "-" + fromDay;
			String to = dpTo.getYear() + "-" + toMonth + "-" + toDay;
			
			String sql = "select * from DATAPAID where DT BETWEEN "
					+ "date('"+from+"')" + " AND " + "date('"+to+"')"
					+ "";
			Cursor resultSet = loginDataBaseAdapter.db.rawQuery(sql, null);

			int rows = 0;
			int cols = 0;
			cols = resultSet.getColumnCount();
			rows = resultSet.getCount();

			resultSet.moveToFirst();

			tb.removeAllViews();

			for (int i = 0; i < rows; i++) {
				TableRow tr = new TableRow(getBaseContext());

				tr.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT,
						LayoutParams.WRAP_CONTENT));

				for (int j = 0; j < cols; j++) {

					TextView tv = new TextView(getBaseContext());
					tv.setLayoutParams(new LayoutParams(
							LayoutParams.WRAP_CONTENT,
							LayoutParams.WRAP_CONTENT));
					tv.setLayoutParams(new LayoutParams(
							LayoutParams.WRAP_CONTENT,
							LayoutParams.WRAP_CONTENT));
					// tv.setBackgroundResource(R.drawable.cell_shape);
					tv.setGravity(Gravity.CENTER);
					tv.setTextSize(18);
					tv.setPadding(0, 5, 0, 5);
					tv.setText(resultSet.getString(j));
					tr.addView(tv);
				}
				resultSet.moveToNext();
				tb.addView(tr);
			}
			resultSet.close();
			break;
		}
	}
}