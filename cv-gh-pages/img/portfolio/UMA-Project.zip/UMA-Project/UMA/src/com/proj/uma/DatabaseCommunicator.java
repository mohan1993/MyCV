package com.proj.uma;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class DatabaseCommunicator {
	static final String DATABASE_NAME = "uma.db";
	static final int DATABASE_VERSION = 1;
	public static final int NAME_COLUMN = 1;
	static final String DATABASE_CREATE = "create table " + "LOGIN" + "( "
			+ "ID" + " integer primary key autoincrement,"
			+ "NAME text, USERNAME  text,PASSWORD text); ";
	static final String DATABASE_PAID_DATA = "create table DATAPAID " +
			"(ID integer primary key autoincrement, " +
			"DT datetime default current_date, " +
			"INTERNAL text, " +
			"EXTERNAL text)";

	public SQLiteDatabase db;
	private final Context context;
	private DBAdapter dbHelper;

	public DatabaseCommunicator(Context _context) {
		context = _context;
		dbHelper = new DBAdapter(context, DATABASE_NAME, null, DATABASE_VERSION);
	}

	public DatabaseCommunicator open() throws SQLException {
		//db = dbHelper.getWritableDatabase();
		db = dbHelper.getWritableDatabase();
		return this;
	}

	public void close() {
		db.close();
	}

	public SQLiteDatabase getDatabaseInstance() {
		return db;
	}

	public void insertEntry(String Name, String userName, String password) {
		ContentValues newValues = new ContentValues();
		// Assign values for each row.
		newValues.put("NAME", Name);
		newValues.put("USERNAME", userName);
		newValues.put("PASSWORD", password);
		db.insert("LOGIN", null, newValues);
	}

	public void insertPaidData(String dt, String internal, String external) {
		ContentValues newValues = new ContentValues();
		// Assign values for each row.
		//newValues.put("DT", dt);
		newValues.put("INTERNAL", internal);
		newValues.put("EXTERNAL", external);
		db.insert("DATAPAID", null, newValues);
	}

	public int deleteEntry(String UserName) {
		// String id=String.valueOf(ID);
		String where = "USERNAME=?";
		int numberOFEntriesDeleted = db.delete("LOGIN", where,
				new String[] { UserName });
		return numberOFEntriesDeleted;
	}

	public String getExistingUser(String userName) {
		Cursor cursor = db.query("LOGIN", null, " USERNAME=?",
				new String[] { userName }, null, null, null);
		if (cursor.getCount() < 1) // UserName Not Exist
		{
			cursor.close();
			return "NOT EXIST";
		}
		cursor.moveToFirst();
		String exuser = cursor.getString(cursor.getColumnIndex("USERNAME"));
		cursor.close();
		return exuser;
	}
	
	public String getSinlgeEntry(String userName) {
		Cursor cursor = db.query("LOGIN", null, " USERNAME=?",
				new String[] { userName }, null, null, null);
		if (cursor.getCount() < 1) // UserName Not Exist
		{
			cursor.close();
			return "NOT EXIST";
		}
		cursor.moveToFirst();
		String password = cursor.getString(cursor.getColumnIndex("PASSWORD"));
		cursor.close();
		return password;
	}

	public void updateEntry(String Name, String userName, String password) {
		ContentValues updatedValues = new ContentValues();
		updatedValues.put("NAME", Name);
		updatedValues.put("USERNAME", userName);
		updatedValues.put("PASSWORD", password);
		String where = "USERNAME = ?";
		db.update("LOGIN", updatedValues, where, new String[] { userName });
	}
	
//	public Cursor getQuery(){
//		
//	}
}