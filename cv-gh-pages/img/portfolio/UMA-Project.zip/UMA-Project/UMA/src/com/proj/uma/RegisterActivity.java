package com.proj.uma;

import com.proj.uba.R;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends Activity implements OnClickListener {

	String name, username, password;
	EditText etName, etUsername, etPassword;
	Button btnRegister;
	DatabaseCommunicator loginDataBaseAdapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.register);

		loginDataBaseAdapter = new DatabaseCommunicator(this);
		loginDataBaseAdapter = loginDataBaseAdapter.open();

		etName = (EditText) findViewById(R.id.etRegName);
		etUsername = (EditText) findViewById(R.id.etRegUsername);
		etPassword = (EditText) findViewById(R.id.etRegPassword);
		btnRegister = (Button) findViewById(R.id.btnRegister);
		btnRegister.setOnClickListener(this);

	}

	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub

		switch (arg0.getId()) {

		case R.id.btnRegister:

			name = etName.getText().toString();
			username = etUsername.getText().toString();
			password = etPassword.getText().toString();

			if (!name.equalsIgnoreCase("") && !username.equalsIgnoreCase("")
					&& !password.equalsIgnoreCase("")) {

				String existingUser = loginDataBaseAdapter
						.getExistingUser(username);
				
				if(!existingUser.equalsIgnoreCase(username)){
					
				loginDataBaseAdapter.insertEntry(name, username, password);
				Toast.makeText(getApplicationContext(),
						"Account Successfully Created ", Toast.LENGTH_LONG)
						.show();
				}else{
					Toast.makeText(getApplicationContext(),
							"User Already Exist", Toast.LENGTH_LONG)
							.show();
				}
			}else{
				Toast.makeText(getApplicationContext(),
						"Please fill all the fields", Toast.LENGTH_LONG)
						.show();
			}			
			break;
		}
	}
}