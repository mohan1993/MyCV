package com.proj.uma;

import com.proj.uba.R;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener {

	Button btnInternal, btnExternal, btnCompare, btnPay, btnShowList,
			btnRefresh;
	EditText etInternal, etExternal;

	String internal, external;

	DatabaseCommunicator loginDataBaseAdapter;

	public boolean comparisson = false;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		loginDataBaseAdapter = new DatabaseCommunicator(this);
		loginDataBaseAdapter = loginDataBaseAdapter.open();

		btnInternal = (Button) findViewById(R.id.btnInternal);
		btnExternal = (Button) findViewById(R.id.btnExternal);
		btnCompare = (Button) findViewById(R.id.btnCompare);
		btnPay = (Button) findViewById(R.id.btnPay);
		btnRefresh = (Button) findViewById(R.id.btnRefresh);

		btnShowList = (Button) findViewById(R.id.btnListofBills);
		etInternal = (EditText) findViewById(R.id.etInternal);
		etExternal = (EditText) findViewById(R.id.etExternal);

		final Values values = (Values) getApplicationContext();

		if (values.getInternalValue() != null) {
			etInternal.setText(values.getInternalValue());
		}

		if (values.getExternalValue() != null) {
			etExternal.setText(values.getExternalValue());
		}
		btnInternal.setOnClickListener(this);
		btnExternal.setOnClickListener(this);
		btnCompare.setOnClickListener(this);
		btnPay.setOnClickListener(this);
		btnShowList.setOnClickListener(this);
		btnRefresh.setOnClickListener(this);
	}

	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub

		switch (arg0.getId()) {

		case R.id.btnRefresh:
			
			final Values values = (Values) getApplicationContext();

			if (values.getInternalValue() != null) {
				etInternal.setText(values.getInternalValue());
			}

			if (values.getExternalValue() != null) {
				etExternal.setText(values.getExternalValue());
			}

			break;

		case R.id.btnInternal:

			Intent internalOCR = new Intent(MainActivity.this,
					OCRInternal.class);
			startActivity(internalOCR);

			break;
		case R.id.btnExternal:

			Intent externalOCR = new Intent(MainActivity.this,
					OCRExternal.class);
			startActivity(externalOCR);

			break;

		case R.id.btnCompare:

			internal = etInternal.getText().toString();
			external = etExternal.getText().toString();

			if (!internal.equalsIgnoreCase("")
					&& !external.equalsIgnoreCase("")) {

				double internalValue = Double.parseDouble(etInternal.getText()
						.toString());
				double externalValue = Double.parseDouble(etExternal.getText()
						.toString());

				double difference = internalValue - externalValue;
				if (difference == 0) {
					comparisson = true;
					Toast.makeText(getApplicationContext(),
							"Both the values are same", Toast.LENGTH_LONG)
							.show();
				} else {
					Toast.makeText(getApplicationContext(),
							"Both internal and external values are different",
							Toast.LENGTH_LONG).show();
				}
			} else {
				Toast.makeText(getApplicationContext(),
						"Capture  the reading and try again...",
						Toast.LENGTH_LONG).show();
			}
			break;
		case R.id.btnPay:

			internal = etInternal.getText().toString();
			external = etExternal.getText().toString();

			if (!internal.equalsIgnoreCase("")
					&& !external.equalsIgnoreCase("")) {
				loginDataBaseAdapter.insertPaidData("", etInternal.getText()
						.toString(), etExternal.getText().toString());
				if (comparisson) {
					Intent browserIntent = new Intent(
							Intent.ACTION_VIEW,
							Uri.parse("http://www.mybills.ie/pages/default.aspx"));
					startActivity(browserIntent);
				} else {
					Toast.makeText(getApplicationContext(),
							"Internal External Readings are of Not Same !!! ",
							Toast.LENGTH_LONG).show();
				}
			} else {
				Toast.makeText(getApplicationContext(),
						"Capture  the reading and try again...",
						Toast.LENGTH_LONG).show();
			}
			break;

		case R.id.btnListofBills:
			Toast.makeText(getApplicationContext(), "List of bills ",
					Toast.LENGTH_LONG).show();
			Intent billList = new Intent(MainActivity.this, ShowDBData.class);
			startActivity(billList);
			break;
		}
	}
}