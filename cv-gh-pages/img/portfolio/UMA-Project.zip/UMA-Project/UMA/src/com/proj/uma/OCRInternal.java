package com.proj.uma;

import com.proj.uba.R;

import Core.CameraEngine;
import Core.Dialogs.ImageDialog;
import Core.ExtraViews.FocusBoxView;
import Core.Imaging.Tools;
import Core.TessTool.TessEngine;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.hardware.Camera;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class OCRInternal extends Activity implements SurfaceHolder.Callback, View.OnClickListener,
        Camera.PictureCallback, Camera.ShutterCallback {

    static final String TAG = "DBG_" + MainActivity.class.getName();

    Button shutterButton;
    Button focusButton;
    FocusBoxView focusBox;
    SurfaceView cameraFrame;
    CameraEngine cameraEngine;

    
    private Bitmap bmpFinal;
    private Activity contextFinal;

    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ocr);
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {

        Log.d(TAG, "Surface Created - starting camera");

        if (cameraEngine != null && !cameraEngine.isOn()) {
            cameraEngine.start();
        }

        if (cameraEngine != null && cameraEngine.isOn()) {
            Log.d(TAG, "Camera engine already on");
            return;
        }

        cameraEngine = CameraEngine.New(holder);
        cameraEngine.start();

        Log.d(TAG, "Camera engine started");
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {

    }

    @SuppressWarnings("deprecation")
	@Override
    protected void onResume() {
        super.onResume();

        cameraFrame = (SurfaceView) findViewById(R.id.camera_frame);
        shutterButton = (Button) findViewById(R.id.shutter_button);
        focusBox = (FocusBoxView) findViewById(R.id.focus_box);
        focusButton = (Button) findViewById(R.id.focus_button);

        shutterButton.setOnClickListener(this);
        focusButton.setOnClickListener(this);

        SurfaceHolder surfaceHolder = cameraFrame.getHolder();
        surfaceHolder.addCallback(this);
        surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);

        cameraFrame.setOnClickListener(this);
    }

    @Override
    protected void onPause() {
        super.onPause();

        if (cameraEngine != null && cameraEngine.isOn()) {
            cameraEngine.stop();
        }

        SurfaceHolder surfaceHolder = cameraFrame.getHolder();
        surfaceHolder.removeCallback(this);
    }

    @Override
    public void onClick(View v) {
        if(v == shutterButton){
            if(cameraEngine != null && cameraEngine.isOn()){
                cameraEngine.takeShot(this, this, this);
            }
        }

        if(v == focusButton){
            if(cameraEngine!=null && cameraEngine.isOn()){
                cameraEngine.requestFocus();
            }
        }
    }

	@TargetApi(Build.VERSION_CODES.HONEYCOMB)
	@Override
    public void onPictureTaken(byte[] data, Camera camera) {

        Log.d(TAG, "Picture taken");

        if (data == null) {
            Log.d(TAG, "Got null data");
            return;
        }

        Bitmap bmp = Tools.getFocusedBitmap(this, camera, data, focusBox.getBox());

        Log.d(TAG, "Got bitmap");

        Log.d(TAG, "Initialization of TessBaseApi");
        
        contextFinal = this;

        bmpFinal = bmp;
        int rotate = 0;
        bmpFinal = Tools.preRotateBitmap(bmpFinal, rotate);
        TessEngine tessEngine =  TessEngine.Generate(contextFinal);

        bmpFinal = bmpFinal.copy(Bitmap.Config.ARGB_8888, true);

        String result = tessEngine.detectText(bmpFinal);

        final Values values = (Values) getApplicationContext();
        values.setInternalValue(result);
        
        
        Log.d(TAG, result);
        Toast.makeText(getApplicationContext(), result, Toast.LENGTH_LONG).show();
        
        ImageDialog.New()
        .addBitmap(bmpFinal)
        .addTitle(result)
        .show(contextFinal.getFragmentManager(), TAG);
        
        this.finish();
        
//        try{
//        	Thread.sleep(5000);
//        }catch(Exception e){
//        	e.printStackTrace();
//        }finally{
//        	Intent main = new Intent(OCRInternal.this, MainActivity.class);
//        	startActivity(main);
//        	this.finish();
//        }
        
    }

	@Override
	public void onShutter() {
		// TODO Auto-generated method stub		
	}
}