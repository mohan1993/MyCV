package com.proj.uma;

import com.proj.uba.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends Activity implements OnClickListener {

	TextView tvSignUp;
	EditText etUsername, etPassword;
	Button btnLogin, btnRegister;
	DatabaseCommunicator loginDataBaseAdapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);

		loginDataBaseAdapter = new DatabaseCommunicator(this);
		loginDataBaseAdapter = loginDataBaseAdapter.open();

		etUsername = (EditText) findViewById(R.id.etUsername);
		etPassword = (EditText) findViewById(R.id.etPassword);
		btnLogin = (Button) findViewById(R.id.btnLogin);
		btnRegister = (Button) findViewById(R.id.btnRegister);
		btnLogin.setOnClickListener(this);
		btnRegister.setOnClickListener(this);
	}

	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub

		switch (arg0.getId()) {

		case R.id.btnRegister:
			Intent reg = new Intent(LoginActivity.this, RegisterActivity.class);
			startActivity(reg);
			break;

		case R.id.btnLogin:

			String username = etUsername.getText().toString();
			String password = etPassword.getText().toString();
			if (!username.equalsIgnoreCase("")
					&& !password.equalsIgnoreCase("")) {
				String storedPassword = loginDataBaseAdapter
						.getSinlgeEntry(username);

				if (password.equals(storedPassword)) {
					Toast.makeText(getApplicationContext(), "Welcome",
							Toast.LENGTH_LONG).show();
					Intent main = new Intent(LoginActivity.this,
							MainActivity.class);
					startActivity(main);

				} else {
					Toast.makeText(getApplicationContext(), "Not a Valid User",
							Toast.LENGTH_LONG).show();
				}
			} else {
				Toast.makeText(getApplicationContext(),
						"Please fill all the fields", Toast.LENGTH_LONG).show();
			}
			break;
		}
	}
}