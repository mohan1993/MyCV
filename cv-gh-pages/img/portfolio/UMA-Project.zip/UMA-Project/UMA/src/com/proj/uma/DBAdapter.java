package com.proj.uma;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

public class DBAdapter extends SQLiteOpenHelper{

	public DBAdapter(Context context, String name, CursorFactory factory,
			int version) {
		super(context, name, factory, version);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onCreate(SQLiteDatabase _db) {
		// TODO Auto-generated method stub
		_db.execSQL(DatabaseCommunicator.DATABASE_CREATE);
		_db.execSQL(DatabaseCommunicator.DATABASE_PAID_DATA);
		//Toast.makeText(null, "created", Toast.LENGTH_LONG).show();
	}

	@Override
	public void onUpgrade(SQLiteDatabase _db, int _oldVersion, int _newVersion) {
		// TODO Auto-generated method stub
		Log.w("TaskDBAdapter", "Upgrading from version " +_oldVersion + " to " +_newVersion + ", which will destroy all old data");
		_db.execSQL("DROP TABLE IF EXISTS " + "TEMPLATE");
		onCreate(_db);
	}
}
