<?php
 // You have to download the Premium version to get working contact form and full documentation of the CV template
?>